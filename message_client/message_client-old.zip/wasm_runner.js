
//wasmRunner(wasmURL: string, callback: function, finalizeRefHack: boolean) -> Promise
//Callback function has the following form: functionName(wasm, go, obj) -> Promise;
function wasmStreamingRunner(wasmURL, callback, finalizeRefHack){
	//Create a new Golang WASM handler and WASM instance object
	const go = new Go(); // Defined in wasm_exec.js
	var wasm;

	//See: https://github.com/tinygo-org/tinygo/issues/1140#issuecomment-1697415864
	//See: https://github.com/tinygo-org/tinygo/issues/1140#issuecomment-1784069413
	if(finalizeRefHack){
		go.importObject.gojs["syscall/js.finalizeRef"] = _ => {
			console.warn("syscall/js.finalizeRef not implemented in TinyGo");
		};
	}

	//Initialize the Promise that will be returned; Thanks CGPT
	return new Promise((resolve, reject) => {
		//Choose the appropriate method to instantiate the WebAssembly module
		const instantiateMethod = "instantiateStreaming" in WebAssembly ?
			WebAssembly.instantiateStreaming :
			async (bytes) => WebAssembly.instantiate(bytes, go.importObject);
	
		//Fetch the WASM file and instantiate it
		fetch(wasmURL)
			.then(resp => {
				if("instantiateStreaming" in WebAssembly){
					//If WebAssembly.instantiateStreaming is available, pass the Response object directly
					return instantiateMethod(resp, go.importObject);
				} 
				else {
					//If not available, convert the Response to an ArrayBuffer first
					return resp.arrayBuffer().then(bytes => instantiateMethod(bytes, go.importObject));
				}
			})
			.then(async obj => {
				try {
					//Invoke the callback and pass the result to resolve
					const result = await callback(wasm, go, obj);
					resolve(result);
				}
				catch (error) {
					//If there's an error, reject the Promise
					reject(error);
				}
			});
	});
}

//Corresponding function
//Setup the WASM function executor
//wasmExec(wasm, go, obj) -> Promise
function wasmExec(wasm, go, obj){
	return new Promise((resolve, reject) => {
		//Run the WASM instance
		wasm = obj.instance;
		go.run(wasm);

		//Generate an ED25519 keypair
		let keypair = ed25519Keygen();
		resolve(keypair);
	});
}